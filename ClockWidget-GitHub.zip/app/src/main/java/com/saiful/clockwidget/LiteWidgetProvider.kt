package com.saiful.clockwidget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.os.Bundle
import android.util.TypedValue
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** কম ভিউয়ের সহজ উইজেট: ফেস ছবি + একটি এনালগ ঘড়ি + একটি ডিজিটাল সময় (টেস্ট ও ব্যাকআপ হিসেবে) */
class LiteWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        val c = Cfg(context)
        c.sysUpdates = c.sysUpdates + 1
        c.lastSys = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        appWidgetIds.forEach { push(context, appWidgetManager, it) }
    }

    override fun onAppWidgetOptionsChanged(
        context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle
    ) {
        push(context, appWidgetManager, appWidgetId)
    }

    companion object {
        fun updateAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            mgr.getAppWidgetIds(ComponentName(ctx, LiteWidgetProvider::class.java)).forEach { push(ctx, mgr, it) }
        }

        fun push(ctx: Context, mgr: AppWidgetManager, id: Int) {
            val app = ctx.applicationContext
            try {
                val c = Cfg(app)
                val rv = RemoteViews(app.packageName, R.layout.clock_widget_lite)
                rv.setImageViewBitmap(R.id.lface, ClockFace.render(c, 512))
                rv.setTextColor(R.id.ltime, c.digital)
                rv.setTextViewTextSize(R.id.ltime, TypedValue.COMPLEX_UNIT_DIP, 22f)
                mgr.updateAppWidget(id, rv)
            } catch (e: Throwable) {
                val rv = RemoteViews(app.packageName, R.layout.widget_error)
                rv.setTextViewText(R.id.errText, "Lite এরর\n" + e.toString().take(200))
                mgr.updateAppWidget(id, rv)
            }
        }
    }
}

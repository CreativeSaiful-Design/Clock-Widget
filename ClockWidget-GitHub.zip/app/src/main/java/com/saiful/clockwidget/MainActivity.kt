package com.saiful.clockwidget

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val tv = TextView(this).apply {
            text = "হোমস্ক্রিনে ফাঁকা জায়গায় লং-প্রেস করুন → Widgets → \"রঙিন এনালগ ঘড়ি\" যোগ করুন"
            textSize = 18f
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        setContentView(tv)
    }
}

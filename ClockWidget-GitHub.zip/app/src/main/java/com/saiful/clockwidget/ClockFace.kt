package com.saiful.clockwidget

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

class HandTheme(val name: String, val hour: Int, val minute: Int, val second: Int)

object ClockFace {
    // (নাম, সিস্টেম ফন্ট ফ্যামিলি) — লেআউটের time*/out* TextClock-এর ক্রমের সাথে মিল রাখতে হবে
    val FONTS = listOf(
        "Black (মোটা)" to "sans-serif-black",
        "Condensed" to "sans-serif-condensed",
        "Medium" to "sans-serif-medium",
        "Serif" to "serif",
        "Monospace" to "monospace",
        "Casual" to "casual",
        "Cursive" to "cursive"
    )

    // এই রংগুলো res/drawable/hand_* ফাইলের সাথে মিলিয়ে রাখতে হবে
    val HANDS = listOf(
        HandTheme("সাদা + লাল সেকেন্ড", 0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt(), 0xFFFF1744.toInt()),
        HandTheme("সায়ান + সাদা সেকেন্ড", 0xFF00E5FF.toInt(), 0xFF00E5FF.toInt(), 0xFFFFFFFF.toInt()),
        HandTheme("নিয়ন সবুজ + লাল সেকেন্ড", 0xFF00E676.toInt(), 0xFF00E676.toInt(), 0xFFFF1744.toInt()),
        HandTheme("সোনালি + লাল সেকেন্ড", 0xFFFFC400.toInt(), 0xFFFFC400.toInt(), 0xFFFF1744.toInt()),
        HandTheme("রঙিন (গোলাপি/নীল/সবুজ)", 0xFFFF4081.toInt(), 0xFF00B0FF.toInt(), 0xFF00E676.toInt())
    )

    val DOT_SHAPES = listOf("গোল বিন্দু", "বর্গ", "ডায়মন্ড", "দণ্ড (লাইন)", "ত্রিভুজ", "তারা", "কিছু না")
    val TICK_SHAPES = listOf("লাইন", "ছোট বিন্দু", "বর্গ", "ডায়মন্ড", "কিছু না")

    private val BN = listOf("১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯", "১০", "১১", "১২")

    /** ডিজিটাল সময়ের অক্ষরের উচ্চতা (ঘড়ির পাশের তুলনায় ভগ্নাংশ) */
    fun timeFrac(c: Cfg, noSec: Boolean = false): Float {
        val len = c.timeFormat(noSec).length
        val ts = c.timeScale / 100f
        return if (c.digitalOutside) minOf(0.17f * ts, 1.6f / len)
        else minOf(0.13f, 0.77f / len) * ts
    }

    /** সময় ঘড়ির বাইরে হলে নিচে যতটা বাড়তি জায়গা লাগবে (ঘড়ির পাশের তুলনায়) */
    fun bandRatio(c: Cfg): Float = if (c.showDigital && c.digitalOutside) 1.35f * timeFrac(c) else 0f

    private fun wa(a: Float) = Color.argb((a.coerceIn(0f, 1f) * 255).toInt(), 255, 255, 255)

    private fun shapePath(c: Cfg, s: Float): Path {
        val path = Path()
        if (c.shape == 0) path.addCircle(s / 2, s / 2, s / 2, Path.Direction.CW)
        else path.addRoundRect(RectF(0f, 0f, s, s), s * 0.16f, s * 0.16f, Path.Direction.CW)
        return path
    }

    /** লেখা যদি maxW-এর চেয়ে চওড়া হয়, ছোট করে বসায় */
    private fun fit(p: Paint, text: String, maxW: Float) {
        val w = p.measureText(text)
        if (w > maxW && w > 0f) p.textSize = p.textSize * maxW / w
    }

    fun render(c: Cfg, size: Int, preview: Boolean = false): Bitmap {
        val s = size.toFloat()
        val band = if (preview) bandRatio(c) else 0f
        val bmp = Bitmap.createBitmap(size, (s * (1 + band)).toInt(), Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val cx = s / 2
        val cy = s / 2
        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        // ব্যাকগ্রাউন্ড রং (স্বচ্ছতাসহ)
        val alpha = c.bgOpacity.coerceIn(0, 100) * 255 / 100
        p.style = Paint.Style.FILL
        p.color = (c.bg and 0xFFFFFF) or (alpha shl 24)
        if (c.shape == 0) cv.drawCircle(cx, cy, s / 2, p)
        else cv.drawRoundRect(RectF(0f, 0f, s, s), s * 0.16f, s * 0.16f, p)

        // নিজের ছবি ব্যাকগ্রাউন্ড
        val photo = c.loadPhoto()
        if (photo != null) {
            cv.save()
            cv.clipPath(shapePath(c, s))
            val pp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
            pp.alpha = alpha
            val z = c.photoZoom.coerceIn(100, 300) / 100f
            val w = photo.width / z
            val h = photo.height / z
            val l = (photo.width - w) / 2
            val t = (photo.height - h) / 2
            cv.drawBitmap(photo, Rect(l.toInt(), t.toInt(), (l + w).toInt(), (t + h).toInt()), RectF(0f, 0f, s, s), pp)
            if (c.photoDim > 0) {
                val dp = Paint()
                dp.color = Color.argb((c.photoDim * 255 / 100) * alpha / 255, 0, 0, 0)
                cv.drawRect(0f, 0f, s, s, dp)
            }
            cv.restore()
        }

        // গ্লসি কাচের ইফেক্ট
        if (c.gloss > 0) drawGloss(c, cv, s)

        // মিনিট/সেকেন্ডের দাগ (শেপ ও সাইজ কাস্টমাইজযোগ্য)
        if (c.tickShape != 4) {
            val ts = c.tickSize / 100f
            p.color = c.tick
            for (i in 0 until 60) {
                if (i % 5 == 0) continue
                val deg = i * 6.0
                val a = Math.toRadians(deg)
                val sn = sin(a).toFloat()
                val cs = cos(a).toFloat()
                if (c.tickShape == 0) {
                    val half = s * 0.0175f * ts
                    val rc = s * 0.4425f
                    p.style = Paint.Style.STROKE
                    p.strokeWidth = s * 0.006f * ts
                    p.strokeCap = Paint.Cap.ROUND
                    cv.drawLine(
                        cx + sn * (rc - half), cy - cs * (rc - half),
                        cx + sn * (rc + half), cy - cs * (rc + half), p
                    )
                } else {
                    p.style = Paint.Style.FILL
                    val shape = when (c.tickShape) { 1 -> 0; 2 -> 1; else -> 2 }
                    drawMarker(cv, p, shape, cx + sn * s * 0.4425f, cy - cs * s * 0.4425f, deg.toFloat(), s * 0.007f * ts)
                }
            }
        }

        // ঘণ্টার মার্কার (১২টি)
        if (c.dotShape != 6) {
            val rr = s * 0.024f * (c.dotSize / 100f)
            val rc = minOf(s * 0.445f, s * 0.49f - rr * 1.35f)
            p.style = Paint.Style.FILL
            p.color = c.dot
            for (i in 0 until 12) {
                val deg = i * 30.0
                val a = Math.toRadians(deg)
                drawMarker(cv, p, c.dotShape, cx + sin(a).toFloat() * rc, cy - cos(a).toFloat() * rc, deg.toFloat(), rr)
            }
        }

        // সংখ্যা ১-১২ (সংখ্যার ফন্ট)
        val np = Paint(Paint.ANTI_ALIAS_FLAG)
        np.typeface = c.typeface(c.fontNum)
        np.color = c.num
        np.textSize = s * 0.1f
        np.textAlign = Paint.Align.CENTER
        for (i in 1..12) {
            val a = Math.toRadians(i * 30.0)
            val x = cx + sin(a).toFloat() * s * 0.345f
            val y = cy - cos(a).toFloat() * s * 0.345f - (np.ascent() + np.descent()) / 2
            cv.drawText(if (c.bn) BN[i - 1] else i.toString(), x, y, np)
        }

        // ব্র্যান্ড লেখা (আলাদা ফন্ট)
        if (c.showBrand && c.brandText.isNotEmpty()) {
            val bp = Paint(Paint.ANTI_ALIAS_FLAG)
            bp.typeface = c.typeface(c.fontBrand)
            bp.color = c.brandC
            bp.textSize = s * 0.045f
            bp.textAlign = Paint.Align.CENTER
            fit(bp, c.brandText, s * 0.6f)
            cv.drawText(c.brandText, cx, s * 0.28f - (bp.ascent() + bp.descent()) / 2, bp)
        }

        // দিন ও তারিখের বক্স (সাইজ অনুযায়ী বড়-ছোট)
        if (c.showDate) {
            val sc = c.dateScale / 100f
            val hw = 0.10f * sc
            val hh = 0.045f * sc
            p.style = Paint.Style.STROKE
            p.color = c.dateC
            p.strokeWidth = s * 0.005f
            cv.drawRoundRect(RectF(s * (0.32f - hw), s * (0.5f - hh), s * (0.32f + hw), s * (0.5f + hh)), s * 0.01f, s * 0.01f, p)
            cv.drawRoundRect(RectF(s * (0.68f - hw), s * (0.5f - hh), s * (0.68f + hw), s * (0.5f + hh)), s * 0.01f, s * 0.01f, p)
        }

        // বার ও তারিখ ছবির ভিতরেই আঁকা হয় (আলাদা ফন্টে; রাত ১২টায় আপডেট হয়)
        if (c.showDate) drawDateTexts(c, cv, s, c.typeface(c.fontDate))

        if (preview) drawPreviewExtras(c, cv, s, band)
        return bmp
    }

    /** তারিখ ও বার ছবির ভিতরে আঁকা (সংখ্যার ফন্টে) */
    private fun drawDateTexts(c: Cfg, cv: Canvas, s: Float, tf: Typeface) {
        val now = Calendar.getInstance()
        val dp = Paint(Paint.ANTI_ALIAS_FLAG)
        dp.typeface = tf
        dp.color = c.dateC
        dp.textSize = s * 0.065f * (c.dateScale / 100f)
        dp.textAlign = Paint.Align.CENTER
        val y = s * 0.5f - (dp.ascent() + dp.descent()) / 2
        val day = SimpleDateFormat("EEE", Locale.getDefault()).format(now.time)
        val date = SimpleDateFormat("MMM d", Locale.getDefault()).format(now.time)
        val maxW = s * 0.2f * (c.dateScale / 100f) * 0.95f
        fit(dp, day, maxW)
        cv.drawText(day, s * 0.32f, y, dp)
        dp.textSize = s * 0.065f * (c.dateScale / 100f)
        fit(dp, date, maxW)
        cv.drawText(date, s * 0.68f, y, dp)
    }

    /**
     * কাস্টম .ttf ফন্টে ডিজিটাল সময়: লাইভ TextClock-এ ফাইল-ফন্ট বসানো যায় না,
     * তাই সময়টা ছবি হিসেবে আঁকা হয় এবং প্রতি মিনিটে নতুন করে আঁকা হয়।
     */
    fun renderTime(c: Cfg, outside: Boolean): Bitmap {
        val w = 600
        val h = if (outside) maxOf(1, (w * bandRatio(c)).toInt()) else (w * 0.22f).toInt()
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val tp = Paint(Paint.ANTI_ALIAS_FLAG)
        tp.typeface = c.typeface(c.fontTime)
        tp.color = c.digital
        tp.textSize = w * timeFrac(c)
        tp.textAlign = Paint.Align.CENTER
        val str = SimpleDateFormat(c.timeFormat(), Locale.getDefault()).format(Date())
        fit(tp, str, w * 0.96f)
        cv.drawText(str, w / 2f, h / 2f - (tp.ascent() + tp.descent()) / 2, tp)
        return bmp
    }

    /** (x, y) বিন্দুতে মার্কার আঁকে; deg = ১২টার দিক থেকে ঘড়ির কাঁটার দিকে কোণ, যাতে শেপ ডায়ালের কেন্দ্রমুখী থাকে */
    private fun drawMarker(cv: Canvas, p: Paint, shape: Int, x: Float, y: Float, deg: Float, r: Float) {
        cv.save()
        cv.rotate(deg, x, y)
        when (shape) {
            0 -> cv.drawCircle(x, y, r, p)
            1 -> cv.drawRect(x - r, y - r, x + r, y + r, p)
            2 -> {
                val path = Path()
                path.moveTo(x, y - r * 1.4f)
                path.lineTo(x + r, y)
                path.lineTo(x, y + r * 1.4f)
                path.lineTo(x - r, y)
                path.close()
                cv.drawPath(path, p)
            }
            3 -> cv.drawRoundRect(RectF(x - r * 0.6f, y - r * 1.8f, x + r * 0.6f, y + r * 1.8f), r * 0.5f, r * 0.5f, p)
            4 -> {
                val path = Path()
                path.moveTo(x, y + r * 1.3f)
                path.lineTo(x - r, y - r * 0.9f)
                path.lineTo(x + r, y - r * 0.9f)
                path.close()
                cv.drawPath(path, p)
            }
            5 -> {
                val path = Path()
                for (k in 0 until 10) {
                    val ang = Math.PI / 5 * k - Math.PI / 2
                    val rad = if (k % 2 == 0) r * 1.3f else r * 0.55f
                    val px = x + (rad * cos(ang)).toFloat()
                    val py = y + (rad * sin(ang)).toFloat()
                    if (k == 0) path.moveTo(px, py) else path.lineTo(px, py)
                }
                path.close()
                cv.drawPath(path, p)
            }
        }
        cv.restore()
    }

    private fun drawGloss(c: Cfg, cv: Canvas, s: Float) {
        val g = c.gloss / 100f
        cv.save()
        cv.clipPath(shapePath(c, s))

        // উপরের অংশে আলোর ঝলক
        val gp = Paint(Paint.ANTI_ALIAS_FLAG)
        gp.style = Paint.Style.FILL
        gp.shader = LinearGradient(0f, s * 0.03f, 0f, s * 0.52f, wa(0.55f * g), wa(0.02f * g), Shader.TileMode.CLAMP)
        cv.drawOval(RectF(s * 0.10f, s * 0.03f, s * 0.90f, s * 0.52f), gp)

        // চকচকে কিনারা
        val rp = Paint(Paint.ANTI_ALIAS_FLAG)
        rp.style = Paint.Style.STROKE
        rp.strokeWidth = s * 0.014f
        rp.shader = LinearGradient(
            0f, 0f, s, s, intArrayOf(wa(0.8f * g), wa(0.05f * g), wa(0.45f * g)), null, Shader.TileMode.CLAMP
        )
        if (c.shape == 0) cv.drawCircle(s / 2, s / 2, s / 2 - s * 0.01f, rp)
        else cv.drawRoundRect(RectF(s * 0.01f, s * 0.01f, s * 0.99f, s * 0.99f), s * 0.15f, s * 0.15f, rp)
        cv.restore()
    }

    // অ্যাপের প্রিভিউতে ডিজিটাল সময়, তারিখ ও কাঁটা দেখানোর জন্য (উইজেটে এগুলো লাইভ view দিয়ে হয়)
    private fun drawPreviewExtras(c: Cfg, cv: Canvas, s: Float, band: Float) {
        val cx = s / 2
        val cy = s / 2
        val now = Calendar.getInstance()
        val fmt = c.timeFormat()

        if (c.showDigital) {
            val tp = Paint(Paint.ANTI_ALIAS_FLAG)
            tp.typeface = c.typeface(c.fontTime)
            tp.color = c.digital
            tp.textSize = s * timeFrac(c)
            tp.textAlign = Paint.Align.CENTER
            val str = SimpleDateFormat(fmt, Locale.getDefault()).format(now.time)
            fit(tp, str, s * 0.96f)
            val yc = if (c.digitalOutside) s + band * s / 2 else s * 0.70f
            cv.drawText(str, cx, yc - (tp.ascent() + tp.descent()) / 2, tp)
        }
        val h = now.get(Calendar.HOUR)
        val m = now.get(Calendar.MINUTE)
        val sec = now.get(Calendar.SECOND)
        val t = HANDS[c.hand]
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        fun hand(deg: Double, front: Float, back: Float, w: Float, col: Int) {
            val a = Math.toRadians(deg)
            val sn = sin(a).toFloat()
            val cs = cos(a).toFloat()
            p.color = col
            p.strokeWidth = w * s
            cv.drawLine(cx - sn * back * s, cy + cs * back * s, cx + sn * front * s, cy - cs * front * s, p)
        }
        hand((h + m / 60.0) * 30, 0.24f, 0.04f, 0.04f, t.hour)
        hand(m * 6.0 + sec * 0.1, 0.32f, 0.05f, 0.0275f, t.minute)
        hand(sec * 6.0, 0.41f, 0.13f, 0.01f, t.second)
        p.style = Paint.Style.FILL
        p.color = t.second
        cv.drawCircle(cx, cy, s * 0.03f, p)
    }
}

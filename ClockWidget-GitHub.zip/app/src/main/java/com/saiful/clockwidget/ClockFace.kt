package com.saiful.clockwidget

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

class HandTheme(val name: String, val hour: Int, val minute: Int, val second: Int)

object ClockFace {
    val FONTS = listOf(
        "Black (মোটা)" to "sans-serif-black",
        "Condensed" to "sans-serif-condensed",
        "Medium" to "sans-serif-medium",
        "Serif" to "serif",
        "Monospace" to "monospace",
        "Casual" to "casual",
        "Cursive" to "cursive"
    )

    // এই রংগুলো res/drawable/hand_* ফাইলের সাথে মিলিয়ে রাখতে হবে
    val HANDS = listOf(
        HandTheme("সাদা + লাল সেকেন্ড", 0xFFFFFFFF.toInt(), 0xFFFFFFFF.toInt(), 0xFFFF1744.toInt()),
        HandTheme("সায়ান + সাদা সেকেন্ড", 0xFF00E5FF.toInt(), 0xFF00E5FF.toInt(), 0xFFFFFFFF.toInt()),
        HandTheme("নিয়ন সবুজ + লাল সেকেন্ড", 0xFF00E676.toInt(), 0xFF00E676.toInt(), 0xFFFF1744.toInt()),
        HandTheme("সোনালি + লাল সেকেন্ড", 0xFFFFC400.toInt(), 0xFFFFC400.toInt(), 0xFFFF1744.toInt()),
        HandTheme("রঙিন (গোলাপি/নীল/সবুজ)", 0xFFFF4081.toInt(), 0xFF00B0FF.toInt(), 0xFF00E676.toInt())
    )

    private val BN = listOf("১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯", "১০", "১১", "১২")

    fun render(c: Cfg, size: Int, preview: Boolean = false): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val s = size.toFloat()
        val cx = s / 2
        val cy = s / 2
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val tf = Typeface.create(FONTS[c.font].second, Typeface.NORMAL)

        // ব্যাকগ্রাউন্ড
        p.style = Paint.Style.FILL
        p.color = c.bg
        if (c.shape == 0) cv.drawCircle(cx, cy, s / 2, p)
        else cv.drawRoundRect(RectF(0f, 0f, s, s), s * 0.16f, s * 0.16f, p)

        // মিনিটের দাগ
        p.style = Paint.Style.STROKE
        p.color = c.tick
        p.strokeWidth = s * 0.006f
        p.strokeCap = Paint.Cap.ROUND
        for (i in 0 until 60) {
            if (i % 5 == 0) continue
            val a = Math.toRadians(i * 6.0)
            val sn = sin(a).toFloat()
            val cs = cos(a).toFloat()
            cv.drawLine(cx + sn * s * 0.425f, cy - cs * s * 0.425f, cx + sn * s * 0.46f, cy - cs * s * 0.46f, p)
        }

        // ঘণ্টার বিন্দু
        p.style = Paint.Style.FILL
        p.color = c.dot
        for (i in 0 until 12) {
            val a = Math.toRadians(i * 30.0)
            cv.drawCircle(cx + sin(a).toFloat() * s * 0.445f, cy - cos(a).toFloat() * s * 0.445f, s * 0.024f, p)
        }

        // সংখ্যা ১-১২
        val np = Paint(Paint.ANTI_ALIAS_FLAG)
        np.typeface = tf
        np.color = c.num
        np.textSize = s * 0.1f
        np.textAlign = Paint.Align.CENTER
        for (i in 1..12) {
            val a = Math.toRadians(i * 30.0)
            val x = cx + sin(a).toFloat() * s * 0.345f
            val y = cy - cos(a).toFloat() * s * 0.345f - (np.ascent() + np.descent()) / 2
            cv.drawText(if (c.bn) BN[i - 1] else i.toString(), x, y, np)
        }

        // ব্র্যান্ড লেখা (ডায়ালের উপরের অংশে)
        if (c.showBrand && c.brandText.isNotEmpty()) {
            val bp = Paint(Paint.ANTI_ALIAS_FLAG)
            bp.typeface = tf
            bp.color = c.brandC
            bp.textSize = s * 0.045f
            bp.textAlign = Paint.Align.CENTER
            cv.drawText(c.brandText, cx, s * 0.28f - (bp.ascent() + bp.descent()) / 2, bp)
        }

        // দিন ও তারিখের বক্স
        if (c.showDate) {
            p.style = Paint.Style.STROKE
            p.color = c.dateC
            p.strokeWidth = s * 0.005f
            cv.drawRoundRect(RectF(s * 0.22f, s * 0.455f, s * 0.42f, s * 0.545f), s * 0.01f, s * 0.01f, p)
            cv.drawRoundRect(RectF(s * 0.58f, s * 0.455f, s * 0.78f, s * 0.545f), s * 0.01f, s * 0.01f, p)
        }

        if (preview) drawPreviewExtras(c, cv, s, tf)
        return bmp
    }

    // অ্যাপের প্রিভিউতে ডিজিটাল সময়, তারিখ ও কাঁটা দেখানোর জন্য (উইজেটে এগুলো লাইভ view দিয়ে হয়)
    private fun drawPreviewExtras(c: Cfg, cv: Canvas, s: Float, tf: Typeface) {
        val cx = s / 2
        val cy = s / 2
        val now = Calendar.getInstance()
        val fmt = c.timeFormat()

        if (c.showDigital) {
            val tp = Paint(Paint.ANTI_ALIAS_FLAG)
            tp.typeface = tf
            tp.color = c.digital
            tp.textSize = s * minOf(0.13f, 0.77f / fmt.length)
            tp.textAlign = Paint.Align.CENTER
            val str = SimpleDateFormat(fmt, Locale.getDefault()).format(now.time)
            cv.drawText(str, cx, s * 0.73f - (tp.ascent() + tp.descent()) / 2, tp)
        }
        if (c.showDate) {
            val dp = Paint(Paint.ANTI_ALIAS_FLAG)
            dp.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            dp.color = c.dateC
            dp.textSize = s * 0.065f
            dp.textAlign = Paint.Align.CENTER
            val y = s * 0.5f - (dp.ascent() + dp.descent()) / 2
            cv.drawText(SimpleDateFormat("EEE", Locale.getDefault()).format(now.time), s * 0.32f, y, dp)
            cv.drawText(SimpleDateFormat("MMM d", Locale.getDefault()).format(now.time), s * 0.68f, y, dp)
        }

        val h = now.get(Calendar.HOUR)
        val m = now.get(Calendar.MINUTE)
        val sec = now.get(Calendar.SECOND)
        val t = HANDS[c.hand]
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        fun hand(deg: Double, front: Float, back: Float, w: Float, col: Int) {
            val a = Math.toRadians(deg)
            val sn = sin(a).toFloat()
            val cs = cos(a).toFloat()
            p.color = col
            p.strokeWidth = w * s
            cv.drawLine(cx - sn * back * s, cy + cs * back * s, cx + sn * front * s, cy - cs * front * s, p)
        }
        hand((h + m / 60.0) * 30, 0.24f, 0.04f, 0.04f, t.hour)
        hand(m * 6.0 + sec * 0.1, 0.32f, 0.05f, 0.0275f, t.minute)
        hand(sec * 6.0, 0.41f, 0.13f, 0.01f, t.second)
        p.style = Paint.Style.FILL
        p.color = t.second
        cv.drawCircle(cx, cy, s * 0.03f, p)
    }
}

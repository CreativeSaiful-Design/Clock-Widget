package com.saiful.clockwidget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.InputFilter
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView

class SettingsActivity : Activity() {

    private lateinit var cfg: Cfg
    private lateinit var preview: ImageView

    private val palette = intArrayOf(
        0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0xFFFF1744.toInt(), 0xFFFF9100.toInt(),
        0xFFFFEA00.toInt(), 0xFF00E676.toInt(), 0xFF1DE9B6.toInt(), 0xFF00E5FF.toInt(),
        0xFF2979FF.toInt(), 0xFF3D5AFE.toInt(), 0xFFD500F9.toInt(), 0xFFFF4081.toInt(),
        0xFF9E9E9E.toInt(), 0xFF0D1B2A.toInt(), 0xFF1A1A2E.toInt()
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = Cfg(this)

        // উইজেট যোগ/রিকনফিগার করার সময় configure হিসেবে খুললে RESULT_OK দিতে হয়
        val wid = intent?.getIntExtra(
            AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (wid != AppWidgetManager.INVALID_APPWIDGET_ID) {
            setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, wid))
        }

        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(8), dp(16), dp(32))
        val scroll = ScrollView(this)
        scroll.addView(root)

        val title = TextView(this)
        title.text = "রঙিন এনালগ ঘড়ি — Design By Saiful"
        title.textSize = 20f
        title.setTypeface(null, Typeface.BOLD)
        root.addView(title)

        // উইজেট লোড টেস্ট: আসল উইজেটের লেআউট এখানেই চালিয়ে দেখা হয়
        val status = TextView(this)
        status.setTextIsSelectable(true)
        status.textSize = 13f
        status.setPadding(0, dp(8), 0, dp(4))
        root.addView(status)
        val live = FrameLayout(this)
        root.addView(live, LinearLayout.LayoutParams(dp(220), dp(220)))
        runWidgetTest(status, live)

        // প্রিভিউয়ের পিছনে রঙিন ব্যাকগ্রাউন্ড, যাতে স্বচ্ছতা বোঝা যায়
        preview = ImageView(this)
        val wall = GradientDrawable(
            GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF5C6BC0.toInt(), 0xFF26A69A.toInt())
        )
        wall.cornerRadius = dp(12).toFloat()
        preview.background = wall
        preview.setPadding(dp(8), dp(8), dp(8), dp(8))
        // প্রিভিউ স্ক্রিনের উপরে স্থির থাকে, শুধু নিচের সেটিংস স্ক্রল করে
        val ph = (resources.displayMetrics.heightPixels * 0.34f).toInt()
        val plp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ph)
        plp.setMargins(dp(12), dp(12), dp(12), dp(4))
        page.addView(preview, plp)
        page.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(page)

        label(root, "— স্টাইল —", true)
        spinner(root, "ফন্ট (সংখ্যা, ডিজিটাল সময়, লেখা)", ClockFace.FONTS.map { it.first }, cfg.font) { cfg.font = it }
        spinner(root, "ঘড়ির আকৃতি", listOf("গোল", "গোল কোণাওয়ালা বর্গ"), cfg.shape) { cfg.shape = it }
        spinner(root, "কাঁটার স্টাইল", ClockFace.HANDS.map { it.name }, cfg.hand) { cfg.hand = it }

        label(root, "— চারদিকের ডট ও দাগ —", true)
        spinner(root, "ঘণ্টার মার্কারের শেপ (১২টি)", ClockFace.DOT_SHAPES, cfg.dotShape) { cfg.dotShape = it }
        slider(root, "ঘণ্টার মার্কারের সাইজ", 50, 200, cfg.dotSize, "%") { cfg.dotSize = it }
        spinner(root, "মিনিট/সেকেন্ডের দাগের শেপ (৪৮টি)", ClockFace.TICK_SHAPES, cfg.tickShape) { cfg.tickShape = it }
        slider(root, "মিনিট/সেকেন্ডের দাগের সাইজ", 50, 200, cfg.tickSize, "%") { cfg.tickSize = it }

        label(root, "— ব্যাকগ্রাউন্ড ও ইফেক্ট —", true)
        slider(root, "ব্যাকগ্রাউন্ড অস্বচ্ছতা (০ = সম্পূর্ণ স্বচ্ছ)", 0, 100, cfg.bgOpacity, "%") { cfg.bgOpacity = it }
        slider(root, "গ্লসি ইফেক্ট (০ = বন্ধ)", 0, 100, cfg.gloss, "%") { cfg.gloss = it }

        label(root, "— ডিজিটাল সময় —", true)
        toggle(root, "ডিজিটাল সময় দেখান", cfg.showDigital) { cfg.showDigital = it }
        toggle(root, "ঘড়ির বাইরে (নিচে) দেখান", cfg.digitalOutside) { cfg.digitalOutside = it }
        slider(root, "ডিজিটাল সময়ের সাইজ", 50, 160, cfg.timeScale, "%") { cfg.timeScale = it }
        toggle(root, "২৪ ঘণ্টা ফরম্যাট", cfg.h24) { cfg.h24 = it }
        toggle(root, "সেকেন্ড দেখান", cfg.seconds) { cfg.seconds = it }

        label(root, "— দিন ও তারিখ —", true)
        toggle(root, "দিন ও তারিখ বক্স দেখান", cfg.showDate) { cfg.showDate = it }
        slider(root, "দিন ও তারিখের সাইজ", 50, 150, cfg.dateScale, "%") { cfg.dateScale = it }

        label(root, "— রং (প্যালেট থেকে বাছুন বা হেক্স লিখুন) —", true)
        colorRow(root, "ব্যাকগ্রাউন্ড", { cfg.bg }, { cfg.bg = it })
        colorRow(root, "সংখ্যা ১-১২", { cfg.num }, { cfg.num = it })
        colorRow(root, "মিনিট/সেকেন্ডের দাগ", { cfg.tick }, { cfg.tick = it })
        colorRow(root, "ঘণ্টার মার্কার", { cfg.dot }, { cfg.dot = it })
        colorRow(root, "ডিজিটাল সময়", { cfg.digital }, { cfg.digital = it })
        colorRow(root, "দিন ও তারিখ", { cfg.dateC }, { cfg.dateC = it })
        colorRow(root, "ব্র্যান্ড লেখা", { cfg.brandC }, { cfg.brandC = it })

        label(root, "— অন্যান্য —", true)
        toggle(root, "বাংলা সংখ্যা (১ ২ ৩ ...)", cfg.bn) { cfg.bn = it }
        toggle(root, "ব্র্যান্ড লেখা দেখান", cfg.showBrand) { cfg.showBrand = it }

        label(root, "ব্র্যান্ড লেখা", false)
        val brand = EditText(this)
        brand.setSingleLine()
        brand.setText(cfg.brandText)
        brand.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(e: Editable?) {
                cfg.brandText = e?.toString() ?: ""
                refresh()
            }
        })
        root.addView(brand)

        val save = Button(this)
        save.text = "সংরক্ষণ করুন ও উইজেট আপডেট করুন"
        save.setOnClickListener {
            ClockWidgetProvider.updateAll(this)
            finish()
        }
        root.addView(save)

        refresh()
    }

    override fun onPause() {
        super.onPause()
        ClockWidgetProvider.updateAll(this)
    }

    private fun runWidgetTest(status: TextView, live: FrameLayout) {
        val rv = ClockWidgetProvider.safeViews(this, 200f, 200f)
        val msg = when (cfg.widgetLevel) {
            0 -> "✅ উইজেট লেআউট ঠিক আছে (পূর্ণ মোড)"
            4 -> "❌ উইজেট লোড হচ্ছে না"
            else -> "⚠️ উইজেট সীমিত মোডে চলছে (লেভেল ${cfg.widgetLevel})"
        }
        status.text = if (cfg.widgetError.isEmpty()) msg else msg + "\n" + cfg.widgetError
        try {
            live.removeAllViews()
            live.addView(rv.apply(this, live))
        } catch (e: Throwable) {
            status.append("\nপ্রিভিউ এরর: " + e.toString())
        }
    }

    private fun refresh() {
        preview.setImageBitmap(ClockFace.render(cfg, 700, true))
    }

    private fun label(parent: LinearLayout, t: String, header: Boolean) {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = if (header) 17f else 15f
        if (header) tv.setTypeface(null, Typeface.BOLD)
        tv.setPadding(0, dp(if (header) 22 else 12), 0, dp(4))
        parent.addView(tv)
    }

    private fun spinner(parent: LinearLayout, title: String, items: List<String>, sel: Int, onSel: (Int) -> Unit) {
        label(parent, title, false)
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        sp.setSelection(sel)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                onSel(pos)
                refresh()
            }
            override fun onNothingSelected(a: AdapterView<*>?) {}
        }
        parent.addView(sp)
    }

    private fun slider(
        parent: LinearLayout, title: String, min: Int, max: Int, value: Int, unit: String, onChange: (Int) -> Unit
    ) {
        val tv = TextView(this)
        tv.text = "$title: $value$unit"
        tv.setPadding(0, dp(12), 0, 0)
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = value.coerceIn(min, max) - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + min
                tv.text = "$title: $v$unit"
                if (fromUser) {
                    onChange(v)
                    refresh()
                }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(tv)
        parent.addView(sb)
    }

    private fun toggle(parent: LinearLayout, title: String, value: Boolean, onChange: (Boolean) -> Unit) {
        val sw = Switch(this)
        sw.text = title
        sw.isChecked = value
        sw.setPadding(0, dp(6), 0, dp(6))
        sw.setOnCheckedChangeListener { _, checked ->
            onChange(checked)
            refresh()
        }
        parent.addView(sw)
    }

    private fun hexOf(c: Int) = String.format("#%06X", c and 0xFFFFFF)

    private fun colorRow(parent: LinearLayout, title: String, get: () -> Int, set: (Int) -> Unit) {
        label(parent, title, false)
        val hex = EditText(this)
        hex.setSingleLine()
        hex.filters = arrayOf(InputFilter.LengthFilter(7))
        hex.setText(hexOf(get()))

        val row = LinearLayout(this)
        for (col in palette) {
            val v = View(this)
            val bgd = GradientDrawable()
            bgd.shape = GradientDrawable.OVAL
            bgd.setColor(col)
            bgd.setStroke(dp(2), 0xFF888888.toInt())
            v.background = bgd
            val lp = LinearLayout.LayoutParams(dp(36), dp(36))
            lp.setMargins(dp(4), 0, dp(4), 0)
            row.addView(v, lp)
            v.setOnClickListener {
                set(col)
                hex.setText(hexOf(col))
                refresh()
            }
        }
        val hs = HorizontalScrollView(this)
        hs.addView(row)
        parent.addView(hs)

        hex.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(e: Editable?) {
                val t = e?.toString() ?: return
                if (t.length == 7 && t[0] == '#') {
                    try {
                        set(Color.parseColor(t))
                        refresh()
                    } catch (_: IllegalArgumentException) {
                    }
                }
            }
        })
        parent.addView(hex, LinearLayout.LayoutParams(dp(140), ViewGroup.LayoutParams.WRAP_CONTENT))
    }
}

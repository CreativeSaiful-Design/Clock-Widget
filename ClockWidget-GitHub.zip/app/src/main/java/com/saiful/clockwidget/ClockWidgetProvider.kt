package com.saiful.clockwidget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.os.Bundle
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews

class ClockWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { update(context, appWidgetManager, it) }
    }

    override fun onAppWidgetOptionsChanged(
        context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle
    ) {
        update(context, appWidgetManager, appWidgetId)
    }

    companion object {
        private val TIME_IDS = intArrayOf(
            R.id.time0, R.id.time1, R.id.time2, R.id.time3, R.id.time4, R.id.time5, R.id.time6
        )
        private val OUT_IDS = intArrayOf(
            R.id.out0, R.id.out1, R.id.out2, R.id.out3, R.id.out4, R.id.out5, R.id.out6
        )
        private val HAND_IDS = intArrayOf(R.id.hand0, R.id.hand1, R.id.hand2, R.id.hand3, R.id.hand4)

        fun updateAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, ClockWidgetProvider::class.java))
            ids.forEach { update(ctx, mgr, it) }
        }

        fun update(ctx: Context, mgr: AppWidgetManager, id: Int) {
            val c = Cfg(ctx)
            val o = mgr.getAppWidgetOptions(id)
            var wDp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 180).toFloat()
            var hDp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 180).toFloat()
            if (wDp <= 0f) wDp = 180f
            if (hDp <= 0f) hDp = 180f
            val d = ctx.resources.displayMetrics.density

            val outside = c.showDigital && c.digitalOutside
            val band = ClockFace.bandRatio(c)               // ঘড়ির বাইরে সময় হলে নিচের বাড়তি জায়গা
            val side = minOf(wDp, hDp / (1 + band))         // ঘড়ির ডায়াল সবসময় বর্গাকার
            val total = side * (1 + band)
            val top = (hDp - total) / 2f
            val padH = ((wDp - side) / 2f * d).toInt()

            val rv = RemoteViews(ctx.packageName, R.layout.clock_widget)
            rv.setViewPadding(R.id.dialBox, padH, (top * d).toInt(), padH, ((hDp - top - side) * d).toInt())
            if (outside) {
                rv.setViewPadding(R.id.outBox, padH, ((top + side) * d).toInt(), padH, (top * d).toInt())
            }
            rv.setImageViewBitmap(R.id.face, ClockFace.render(c, 600))

            // ডিজিটাল সময়: ঘড়ির ভিতরে (time*) অথবা বাইরে (out*)
            val fmt = c.timeFormat()
            val timeSize = side * ClockFace.timeFrac(c)
            for (i in 0 until 7) {
                val inside = c.showDigital && !c.digitalOutside && i == c.font
                val out = outside && i == c.font
                rv.setViewVisibility(TIME_IDS[i], if (inside) View.VISIBLE else View.GONE)
                rv.setViewVisibility(OUT_IDS[i], if (out) View.VISIBLE else View.GONE)
                for (vid in intArrayOf(TIME_IDS[i], OUT_IDS[i])) {
                    rv.setCharSequence(vid, "setFormat12Hour", fmt)
                    rv.setCharSequence(vid, "setFormat24Hour", fmt)
                    rv.setTextColor(vid, c.digital)
                    rv.setTextViewTextSize(vid, TypedValue.COMPLEX_UNIT_DIP, timeSize)
                }
            }

            // দিন ও তারিখ (সাইজ স্লাইডার অনুযায়ী)
            intArrayOf(R.id.day, R.id.date).forEach { vid ->
                rv.setViewVisibility(vid, if (c.showDate) View.VISIBLE else View.GONE)
                rv.setTextColor(vid, c.dateC)
                rv.setTextViewTextSize(vid, TypedValue.COMPLEX_UNIT_DIP, side * 0.065f * (c.dateScale / 100f))
            }

            // কাঁটার স্টাইল
            HAND_IDS.forEachIndexed { i, vid ->
                rv.setViewVisibility(vid, if (i == c.hand) View.VISIBLE else View.GONE)
            }

            // এখানে ইচ্ছা করেই কোনো ক্লিক সেট করা হয়নি, তাই উইজেটে ট্যাপ করলে অ্যাপ খুলবে না

            mgr.updateAppWidget(id, rv)
        }
    }
}

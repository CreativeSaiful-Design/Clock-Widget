package com.saiful.clockwidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews

class ClockWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { update(context, appWidgetManager, it) }
    }

    override fun onAppWidgetOptionsChanged(
        context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle
    ) {
        update(context, appWidgetManager, appWidgetId)
    }

    companion object {
        private val TIME_IDS = intArrayOf(
            R.id.time0, R.id.time1, R.id.time2, R.id.time3, R.id.time4, R.id.time5, R.id.time6
        )
        private val HAND_IDS = intArrayOf(R.id.hand0, R.id.hand1, R.id.hand2, R.id.hand3, R.id.hand4)

        fun updateAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, ClockWidgetProvider::class.java))
            ids.forEach { update(ctx, mgr, it) }
        }

        fun update(ctx: Context, mgr: AppWidgetManager, id: Int) {
            val c = Cfg(ctx)
            val o = mgr.getAppWidgetOptions(id)
            var wDp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 180)
            var hDp = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 180)
            if (wDp <= 0) wDp = 180
            if (hDp <= 0) hDp = 180
            val side = minOf(wDp, hDp).toFloat()
            val d = ctx.resources.displayMetrics.density
            val padH = ((wDp - side) / 2 * d).toInt()
            val padV = ((hDp - side) / 2 * d).toInt()

            val rv = RemoteViews(ctx.packageName, R.layout.clock_widget)
            rv.setViewPadding(R.id.root, padH, padV, padH, padV) // ঘড়ি সবসময় বর্গাকার থাকবে
            rv.setImageViewBitmap(R.id.face, ClockFace.render(c, 600))

            // ডিজিটাল সময় (লাইভ TextClock)
            val fmt = c.timeFormat()
            TIME_IDS.forEachIndexed { i, vid ->
                rv.setViewVisibility(vid, if (c.showDigital && i == c.font) View.VISIBLE else View.GONE)
                rv.setCharSequence(vid, "setFormat12Hour", fmt)
                rv.setCharSequence(vid, "setFormat24Hour", fmt)
                rv.setTextColor(vid, c.digital)
                rv.setTextViewTextSize(
                    vid, TypedValue.COMPLEX_UNIT_DIP, side * minOf(0.13f, 0.77f / fmt.length)
                )
            }

            // দিন ও তারিখ
            intArrayOf(R.id.day, R.id.date).forEach { vid ->
                rv.setViewVisibility(vid, if (c.showDate) View.VISIBLE else View.GONE)
                rv.setTextColor(vid, c.dateC)
                rv.setTextViewTextSize(vid, TypedValue.COMPLEX_UNIT_DIP, side * 0.065f)
            }

            // কাঁটার স্টাইল
            HAND_IDS.forEachIndexed { i, vid ->
                rv.setViewVisibility(vid, if (i == c.hand) View.VISIBLE else View.GONE)
            }

            // উইজেটে ট্যাপ করলে সেটিংস খুলবে
            val pi = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, SettingsActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            rv.setOnClickPendingIntent(R.id.root, pi)

            mgr.updateAppWidget(id, rv)
        }
    }
}

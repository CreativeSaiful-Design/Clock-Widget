package com.saiful.clockwidget

import android.appwidget.AppWidgetProvider

// AnalogClock সিস্টেম নিজেই লাইভ আপডেট করে, তাই এখানে কোড লাগে না
class ClockWidgetProvider : AppWidgetProvider()

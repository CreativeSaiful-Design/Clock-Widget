package com.saiful.clockwidget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.os.Bundle
import android.util.TypedValue
import android.view.View
import android.widget.FrameLayout
import android.widget.RemoteViews

class ClockWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { update(context, appWidgetManager, it) }
    }

    override fun onAppWidgetOptionsChanged(
        context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle
    ) {
        update(context, appWidgetManager, appWidgetId)
    }

    companion object {
        private val TIME_IDS = intArrayOf(
            R.id.time0, R.id.time1, R.id.time2, R.id.time3, R.id.time4, R.id.time5, R.id.time6
        )
        private val OUT_IDS = intArrayOf(
            R.id.out0, R.id.out1, R.id.out2, R.id.out3, R.id.out4, R.id.out5, R.id.out6
        )
        private val HAND_IDS = intArrayOf(R.id.hand0, R.id.hand1, R.id.hand2, R.id.hand3, R.id.hand4)

        fun updateAll(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, ClockWidgetProvider::class.java))
            ids.forEach { update(ctx, mgr, it) }
        }

        fun update(ctx: Context, mgr: AppWidgetManager, id: Int) {
            val o = mgr.getAppWidgetOptions(id)
            val w = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 180).toFloat()
            val h = o.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 180).toFloat()
            mgr.updateAppWidget(id, safeViews(ctx, w, h))
        }

        /**
         * লেভেল ০ = সব ফিচার। কোনো ধাপে লোড ফেল করলে ধাপে ধাপে ফিচার কমিয়ে আবার চেষ্টা করে।
         * কোন লেভেলে কী এরর হয়েছিল তা Cfg-তে রাখা হয়, অ্যাপের উপরে দেখা যায়।
         */
        fun safeViews(ctx: Context, wDp: Float, hDp: Float): RemoteViews {
            val app = ctx.applicationContext
            val cfg = Cfg(app)
            val log = StringBuilder()
            for (level in 0..3) {
                try {
                    val rv = build(app, wDp, hDp, level)
                    rv.apply(app, FrameLayout(app)) // ইনফ্লেট ও অ্যাকশন চালিয়ে আগেই পরীক্ষা
                    cfg.widgetLevel = level
                    cfg.widgetError = log.toString()
                    return rv
                } catch (e: Throwable) {
                    log.append("L").append(level).append(": ").append(e.toString())
                    e.cause?.let { log.append(" <- ").append(it.toString()) }
                    log.append("\n")
                }
            }
            cfg.widgetLevel = 4
            cfg.widgetError = log.toString()
            val rv = RemoteViews(app.packageName, R.layout.widget_error)
            rv.setTextViewText(R.id.errText, "উইজেট এরর\n" + log.toString().take(300))
            return rv
        }

        private fun build(ctx: Context, wIn: Float, hIn: Float, level: Int): RemoteViews {
            val c = Cfg(ctx)
            val wDp = if (wIn > 0f) wIn else 180f
            val hDp = if (hIn > 0f) hIn else 180f
            val d = ctx.resources.displayMetrics.density

            val outside = level < 2 && c.showDigital && c.digitalOutside
            val band = if (outside) ClockFace.bandRatio(c) else 0f
            val side = minOf(wDp, hDp / (1 + band))
            val total = side * (1 + band)
            val top = (hDp - total) / 2f
            val padH = ((wDp - side) / 2f * d).toInt()

            val rv = RemoteViews(ctx.packageName, R.layout.clock_widget)
            if (level < 2) {
                rv.setViewPadding(R.id.dialBox, padH, (top * d).toInt(), padH, ((hDp - top - side) * d).toInt())
                if (outside) {
                    rv.setViewPadding(R.id.outBox, padH, ((top + side) * d).toInt(), padH, (top * d).toInt())
                }
            }
            rv.setImageViewBitmap(R.id.face, ClockFace.render(c, 600))

            // ডিজিটাল সময়
            val fmt = c.timeFormat()
            val timeSize = side * ClockFace.timeFrac(c)
            for (i in 0 until 7) {
                val inside = level < 3 && c.showDigital && !outside && i == c.font
                val out = level < 3 && outside && i == c.font
                rv.setViewVisibility(TIME_IDS[i], if (inside) View.VISIBLE else View.GONE)
                rv.setViewVisibility(OUT_IDS[i], if (out) View.VISIBLE else View.GONE)
                if (level < 3 && (inside || out)) {
                    val vid = if (inside) TIME_IDS[i] else OUT_IDS[i]
                    if (level < 1) {
                        rv.setCharSequence(vid, "setFormat12Hour", fmt)
                        rv.setCharSequence(vid, "setFormat24Hour", fmt)
                    }
                    rv.setTextColor(vid, c.digital)
                    rv.setTextViewTextSize(vid, TypedValue.COMPLEX_UNIT_DIP, timeSize)
                }
            }

            // দিন ও তারিখ
            val showDate = level < 3 && c.showDate
            intArrayOf(R.id.day, R.id.date).forEach { vid ->
                rv.setViewVisibility(vid, if (showDate) View.VISIBLE else View.GONE)
                if (showDate) {
                    rv.setTextColor(vid, c.dateC)
                    rv.setTextViewTextSize(vid, TypedValue.COMPLEX_UNIT_DIP, side * 0.065f * (c.dateScale / 100f))
                }
            }

            // কাঁটার স্টাইল
            HAND_IDS.forEachIndexed { i, vid ->
                rv.setViewVisibility(vid, if (i == c.hand) View.VISIBLE else View.GONE)
            }

            // ইচ্ছা করেই কোনো ক্লিক সেট করা হয়নি (ট্যাপে অ্যাপ খুলবে না)
            return rv
        }
    }
}

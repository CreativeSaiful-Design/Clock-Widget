package com.saiful.clockwidget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Typeface
import java.io.File
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

/** সব সেটিং এক জায়গায় (SharedPreferences) + কাস্টম ফন্ট/ছবির ফাইল */
class Cfg(ctx: Context) {
    private val appCtx = ctx.applicationContext
    private val p = appCtx.getSharedPreferences("clock_cfg", Context.MODE_PRIVATE)

    private fun int(k: String, d: Int): ReadWriteProperty<Any?, Int> = object : ReadWriteProperty<Any?, Int> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): Int = p.getInt(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) { p.edit().putInt(k, value).apply() }
    }
    private fun bool(k: String, d: Boolean): ReadWriteProperty<Any?, Boolean> = object : ReadWriteProperty<Any?, Boolean> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): Boolean = p.getBoolean(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) { p.edit().putBoolean(k, value).apply() }
    }
    private fun str(k: String, d: String): ReadWriteProperty<Any?, String> = object : ReadWriteProperty<Any?, String> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): String = p.getString(k, d) ?: d
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: String) { p.edit().putString(k, value).apply() }
    }

    // রং
    var bg by int("bg", 0xFF000000.toInt())
    var num by int("num", 0xFFFFFFFF.toInt())
    var tick by int("tick", 0xFF2979FF.toInt())
    var dot by int("dot", 0xFF00E676.toInt())
    var digital by int("digital", 0xFFFF1744.toInt())
    var dateC by int("dateC", 0xFF00E676.toInt())
    var brandC by int("brandC", 0xFF1DE9B6.toInt())

    // ফন্ট: "sans-serif-medium" (সিস্টেম ফন্ট) অথবা "ttf:ফাইলের নাম" (আপলোড করা)
    var fontNum by str("fontNum", "sans-serif-medium")
    var fontTime by str("fontTime", "sans-serif-medium")
    var fontBrand by str("fontBrand", "sans-serif-medium")

    // স্টাইল
    var shape by int("shape", 0)
    var hand by int("hand", 0)

    // অন/অফ
    var h24 by bool("h24", false)
    var seconds by bool("seconds", false)
    var showDate by bool("showDate", true)
    var showBrand by bool("showBrand", true)
    var showDigital by bool("showDigital", true)
    var bn by bool("bn", false)
    var digitalOutside by bool("digitalOutside", false)

    // স্লাইডার (শতকরা)
    var dateScale by int("dateScale", 100)
    var timeScale by int("timeScale", 100)
    var bgOpacity by int("bgOpacity", 100)
    var gloss by int("gloss", 30)

    // ডট ও দাগের শেপ/সাইজ
    var dotShape by int("dotShape", 0)
    var dotSize by int("dotSize", 100)
    var tickShape by int("tickShape", 0)
    var tickSize by int("tickSize", 100)

    // ব্যাকগ্রাউন্ড ছবি
    var usePhoto by bool("usePhoto", false)
    var photoZoom by int("photoZoom", 100)
    var photoDim by int("photoDim", 20)

    // ডায়াগনস্টিক: উইজেট কোন মোডে লোড হয়েছে ও এরর
    var widgetLevel by int("widgetLevel", 0)
    var widgetError by str("widgetError", "")

    var brandText by str("brandText", "Design By Saiful")

    // ---------- ফন্ট ----------
    fun fontsDir(): File {
        val d = File(appCtx.filesDir, "fonts")
        if (!d.exists()) d.mkdirs()
        return d
    }

    fun customFonts(): List<String> =
        (fontsDir().listFiles() ?: emptyArray()).map { it.name }
            .filter { val n = it.lowercase(); n.endsWith(".ttf") || n.endsWith(".otf") }
            .sorted()

    fun fontKeys(): List<String> = ClockFace.FONTS.map { it.second } + customFonts().map { "ttf:$it" }

    fun fontNames(): List<String> =
        ClockFace.FONTS.map { it.first } + customFonts().map { "📁 " + it.substringBeforeLast('.') }

    private fun isCustomKey(key: String) = key.startsWith("ttf:") && File(fontsDir(), key.substring(4)).exists()

    fun typeface(key: String): Typeface {
        if (key.startsWith("ttf:")) {
            val f = File(fontsDir(), key.substring(4))
            if (f.exists()) {
                val ck = f.absolutePath + f.lastModified()
                tfCache[ck]?.let { return it }
                try {
                    val tf = Typeface.createFromFile(f)
                    tfCache[ck] = tf
                    return tf
                } catch (e: Exception) {
                }
            }
            return Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        return Typeface.create(key, Typeface.NORMAL)
    }

    /** ডিজিটাল সময়ের ফন্ট আপলোড করা হলে true (তখন সময় ছবি হিসেবে আঁকা হয়) */
    fun customTime(): Boolean = isCustomKey(fontTime)

    /** ডিজিটাল সময়ের সিস্টেম ফন্টের ইনডেক্স (লেআউটের TextClock বাছাইয়ের জন্য) */
    fun timeFontSysIndex(): Int {
        val i = ClockFace.FONTS.indexOfFirst { it.second == fontTime }
        return if (i >= 0) i else 2
    }

    fun timeFormat(): String {
        val sec = seconds && !customTime() // কাস্টম ফন্টে সেকেন্ড সাপোর্ট নেই
        val base = if (h24) "HH:mm" else "hh:mm"
        return base + (if (sec) ":ss" else "") + (if (h24) "" else " a")
    }

    // ---------- ব্যাকগ্রাউন্ড ছবি ----------
    val photoFile: File get() = File(appCtx.filesDir, "bg_photo.jpg")

    fun loadPhoto(): Bitmap? {
        val f = photoFile
        if (!usePhoto || !f.exists()) return null
        val stamp = f.lastModified() + f.length()
        val cur = photoCache
        if (cur != null && photoStamp == stamp) return cur
        val b = BitmapFactory.decodeFile(f.absolutePath)
        photoCache = b
        photoStamp = stamp
        return b
    }

    companion object {
        private val tfCache = HashMap<String, Typeface>()
        private var photoCache: Bitmap? = null
        private var photoStamp = 0L
    }
}

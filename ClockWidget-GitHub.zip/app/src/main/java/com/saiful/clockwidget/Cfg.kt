package com.saiful.clockwidget

import android.content.Context
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

/** সব সেটিং এক জায়গায় (SharedPreferences) */
class Cfg(ctx: Context) {
    private val p = ctx.getSharedPreferences("clock_cfg", Context.MODE_PRIVATE)

    private fun int(k: String, d: Int): ReadWriteProperty<Any?, Int> = object : ReadWriteProperty<Any?, Int> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): Int = p.getInt(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Int) { p.edit().putInt(k, value).apply() }
    }
    private fun bool(k: String, d: Boolean): ReadWriteProperty<Any?, Boolean> = object : ReadWriteProperty<Any?, Boolean> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): Boolean = p.getBoolean(k, d)
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: Boolean) { p.edit().putBoolean(k, value).apply() }
    }
    private fun str(k: String, d: String): ReadWriteProperty<Any?, String> = object : ReadWriteProperty<Any?, String> {
        override fun getValue(thisRef: Any?, property: KProperty<*>): String = p.getString(k, d) ?: d
        override fun setValue(thisRef: Any?, property: KProperty<*>, value: String) { p.edit().putString(k, value).apply() }
    }

    // রং
    var bg by int("bg", 0xFF000000.toInt())
    var num by int("num", 0xFFFFFFFF.toInt())
    var tick by int("tick", 0xFF2979FF.toInt())
    var dot by int("dot", 0xFF00E676.toInt())
    var digital by int("digital", 0xFFFF1744.toInt())
    var dateC by int("dateC", 0xFF00E676.toInt())
    var brandC by int("brandC", 0xFF1DE9B6.toInt())

    // স্টাইল
    var font by int("font", 2)
    var shape by int("shape", 0)
    var hand by int("hand", 0)

    // অন/অফ
    var h24 by bool("h24", false)
    var seconds by bool("seconds", false)
    var showDate by bool("showDate", true)
    var showBrand by bool("showBrand", true)
    var showDigital by bool("showDigital", true)
    var bn by bool("bn", false)
    var digitalOutside by bool("digitalOutside", false)

    // স্লাইডার (শতকরা)
    var dateScale by int("dateScale", 100)
    var timeScale by int("timeScale", 100)
    var bgOpacity by int("bgOpacity", 100)
    var gloss by int("gloss", 30)

    // ডট ও দাগের শেপ/সাইজ
    var dotShape by int("dotShape", 0)
    var dotSize by int("dotSize", 100)
    var tickShape by int("tickShape", 0)
    var tickSize by int("tickSize", 100)

    var brandText by str("brandText", "Design By Saiful")

    fun timeFormat(): String {
        val base = if (h24) "HH:mm" else "hh:mm"
        return base + (if (seconds) ":ss" else "") + (if (h24) "" else " a")
    }
}

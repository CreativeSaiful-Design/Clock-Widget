package com.saiful.clockwidget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.text.Editable
import android.text.InputFilter
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

class SettingsActivity : Activity() {

    private lateinit var cfg: Cfg
    private lateinit var preview: ImageView
    private lateinit var photoSwitch: Switch

    private class FontRow(val spinner: Spinner, val get: () -> String, val set: (String) -> Unit)
    private val fontRows = mutableListOf<FontRow>()

    private val REQ_PHOTO = 101
    private val REQ_FONT = 102

    private val palette = intArrayOf(
        0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0xFFFF1744.toInt(), 0xFFFF9100.toInt(),
        0xFFFFEA00.toInt(), 0xFF00E676.toInt(), 0xFF1DE9B6.toInt(), 0xFF00E5FF.toInt(),
        0xFF2979FF.toInt(), 0xFF3D5AFE.toInt(), 0xFFD500F9.toInt(), 0xFFFF4081.toInt(),
        0xFF9E9E9E.toInt(), 0xFF0D1B2A.toInt(), 0xFF1A1A2E.toInt()
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = Cfg(this)

        // উইজেট যোগ/রিকনফিগার করার সময় configure হিসেবে খুললে RESULT_OK দিতে হয়
        val wid = intent?.getIntExtra(
            AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID
        if (wid != AppWidgetManager.INVALID_APPWIDGET_ID) {
            setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, wid))
        }

        val page = LinearLayout(this)
        page.orientation = LinearLayout.VERTICAL
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(8), dp(16), dp(32))
        val scroll = ScrollView(this)
        scroll.addView(root)

        // প্রিভিউ স্ক্রিনের উপরে স্থির থাকে, শুধু নিচের সেটিংস স্ক্রল করে
        preview = ImageView(this)
        val wall = GradientDrawable(
            GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF5C6BC0.toInt(), 0xFF26A69A.toInt())
        )
        wall.cornerRadius = dp(12).toFloat()
        preview.background = wall
        preview.setPadding(dp(8), dp(8), dp(8), dp(8))
        val ph = (resources.displayMetrics.heightPixels * 0.34f).toInt()
        val plp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ph)
        plp.setMargins(dp(12), dp(12), dp(12), dp(4))
        page.addView(preview, plp)
        page.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(page)

        val title = TextView(this)
        title.text = "Clock By Saiful"
        title.textSize = 20f
        title.setTypeface(null, Typeface.BOLD)
        root.addView(title)

        // উইজেট লোড টেস্ট: আসল উইজেটের লেআউট এখানেই চালিয়ে দেখা হয়
        val status = TextView(this)
        status.setTextIsSelectable(true)
        status.textSize = 13f
        status.setPadding(0, dp(8), 0, dp(4))
        root.addView(status)
        val live = FrameLayout(this)
        root.addView(live, LinearLayout.LayoutParams(dp(220), dp(220)))
        runWidgetTest(status, live)

        // ---------- ফন্ট ----------
        label(root, "— ফন্ট —", true)
        val uniSwitch = Switch(this)
        uniSwitch.text = "🌐 ইউনিভার্সাল ফন্ট (সব লেখায় একই ফন্ট)"
        uniSwitch.isChecked = cfg.useUniversal
        uniSwitch.setPadding(0, dp(6), 0, dp(6))
        root.addView(uniSwitch)
        fontSpinner(root, "ইউনিভার্সাল ফন্ট (সময়, তারিখ, বার, সংখ্যা, ব্র্যান্ড সব জায়গায়)", { cfg.fontAll }, { cfg.fontAll = it })
        label(root, "অথবা আলাদা আলাদা ফন্ট (ইউনিভার্সাল বন্ধ থাকলে কাজ করবে):", false)
        fontSpinner(root, "সংখ্যা ১-১২ এর ফন্ট", { cfg.fontNum }, { cfg.fontNum = it })
        fontSpinner(root, "ডিজিটাল সময়ের ফন্ট", { cfg.fontTime }, { cfg.fontTime = it })
        fontSpinner(root, "ব্র্যান্ড লেখার ফন্ট (Design By Saiful)", { cfg.fontBrand }, { cfg.fontBrand = it })
        fontSpinner(root, "বার ও তারিখের ফন্ট", { cfg.fontDate }, { cfg.fontDate = it })
        val applyUni = {
            for (i in fontRows.indices) {
                val enabled = if (i == 0) cfg.useUniversal else !cfg.useUniversal
                fontRows[i].spinner.isEnabled = enabled
                fontRows[i].spinner.alpha = if (enabled) 1f else 0.4f
            }
        }
        applyUni()
        uniSwitch.setOnCheckedChangeListener { _, checked ->
            cfg.useUniversal = checked
            applyUni()
            refresh()
        }
        val addFont = Button(this)
        addFont.text = "📂 .ttf / .otf ফন্ট যোগ করুন"
        addFont.setOnClickListener { pickFile("*/*", REQ_FONT) }
        root.addView(addFont)
        val delFont = Button(this)
        delFont.text = "যোগ করা সব ফন্ট মুছুন"
        delFont.setOnClickListener {
            cfg.fontsDir().listFiles()?.forEach { it.delete() }
            fontRows.forEach { bindFontRow(it) }
            refresh()
            toast("কাস্টম ফন্ট মুছে ফেলা হয়েছে")
        }
        root.addView(delFont)
        val fontNote = TextView(this)
        fontNote.text = "বাংলা সংখ্যা বা বাংলা লেখার জন্য বাংলা ফন্ট (যেমন SolaimanLipi, Kalpurush) যোগ করুন। " +
            "কাস্টম ফন্টে ডিজিটাল সময় ছবি হিসেবে আঁকা হয় ও প্রতি মিনিটে বদলায়; সেকেন্ড দেখানো যায় না।"
        fontNote.textSize = 12f
        fontNote.setPadding(0, dp(4), 0, 0)
        root.addView(fontNote)

        // ---------- স্টাইল ----------
        label(root, "— স্টাইল —", true)
        spinner(root, "ঘড়ির আকৃতি", listOf("গোল", "গোল কোণাওয়ালা বর্গ"), cfg.shape) { cfg.shape = it }
        spinner(root, "কাঁটার স্টাইল", ClockFace.HANDS.map { it.name }, cfg.hand) { cfg.hand = it }

        label(root, "— চারদিকের ডট ও দাগ —", true)
        spinner(root, "ঘণ্টার মার্কারের শেপ (১২টি)", ClockFace.DOT_SHAPES, cfg.dotShape) { cfg.dotShape = it }
        slider(root, "ঘণ্টার মার্কারের সাইজ", 50, 200, cfg.dotSize, "%") { cfg.dotSize = it }
        spinner(root, "মিনিট/সেকেন্ডের দাগের শেপ (৪৮টি)", ClockFace.TICK_SHAPES, cfg.tickShape) { cfg.tickShape = it }
        slider(root, "মিনিট/সেকেন্ডের দাগের সাইজ", 50, 200, cfg.tickSize, "%") { cfg.tickSize = it }

        // ---------- ব্যাকগ্রাউন্ড ----------
        label(root, "— ব্যাকগ্রাউন্ড ও ইফেক্ট —", true)
        slider(root, "ব্যাকগ্রাউন্ড অস্বচ্ছতা (০ = সম্পূর্ণ স্বচ্ছ)", 0, 100, cfg.bgOpacity, "%") { cfg.bgOpacity = it }
        slider(root, "গ্লসি ইফেক্ট (০ = বন্ধ)", 0, 100, cfg.gloss, "%") { cfg.gloss = it }

        val pick = Button(this)
        pick.text = "🖼️ নিজের ছবি ব্যাকগ্রাউন্ডে দিন"
        pick.setOnClickListener { pickFile("image/*", REQ_PHOTO) }
        root.addView(pick)
        photoSwitch = Switch(this)
        photoSwitch.text = "ছবি ব্যাকগ্রাউন্ড ব্যবহার করুন"
        photoSwitch.isChecked = cfg.usePhoto && cfg.photoFile.exists()
        photoSwitch.setPadding(0, dp(6), 0, dp(6))
        photoSwitch.setOnCheckedChangeListener { _, checked ->
            if (checked && !cfg.photoFile.exists()) {
                photoSwitch.isChecked = false
                toast("আগে একটি ছবি বাছুন")
            } else {
                cfg.usePhoto = checked
                refresh()
            }
        }
        root.addView(photoSwitch)
        slider(root, "ছবি জুম", 100, 300, cfg.photoZoom, "%") { cfg.photoZoom = it }
        slider(root, "ছবির উপর কালো আবরণ (লেখা স্পষ্ট করতে)", 0, 80, cfg.photoDim, "%") { cfg.photoDim = it }

        // ---------- ডিজিটাল সময় ----------
        label(root, "— ডিজিটাল সময় —", true)
        toggle(root, "ডিজিটাল সময় দেখান", cfg.showDigital) { cfg.showDigital = it }
        toggle(root, "ঘড়ির বাইরে (নিচে) দেখান", cfg.digitalOutside) { cfg.digitalOutside = it }
        slider(root, "ডিজিটাল সময়ের সাইজ", 50, 160, cfg.timeScale, "%") { cfg.timeScale = it }
        toggle(root, "২৪ ঘণ্টা ফরম্যাট", cfg.h24) { cfg.h24 = it }
        toggle(root, "সেকেন্ড দেখান (শুধু সিস্টেম ফন্টে)", cfg.seconds) { cfg.seconds = it }

        label(root, "— দিন ও তারিখ —", true)
        toggle(root, "দিন ও তারিখ বক্স দেখান", cfg.showDate) { cfg.showDate = it }
        slider(root, "দিন ও তারিখের সাইজ", 50, 150, cfg.dateScale, "%") { cfg.dateScale = it }

        label(root, "— রং (প্যালেট থেকে বাছুন বা হেক্স লিখুন) —", true)
        colorRow(root, "ব্যাকগ্রাউন্ড", { cfg.bg }, { cfg.bg = it })
        colorRow(root, "সংখ্যা ১-১২", { cfg.num }, { cfg.num = it })
        colorRow(root, "মিনিট/সেকেন্ডের দাগ", { cfg.tick }, { cfg.tick = it })
        colorRow(root, "ঘণ্টার মার্কার", { cfg.dot }, { cfg.dot = it })
        colorRow(root, "ডিজিটাল সময়", { cfg.digital }, { cfg.digital = it })
        colorRow(root, "দিন ও তারিখ", { cfg.dateC }, { cfg.dateC = it })
        colorRow(root, "ব্র্যান্ড লেখা", { cfg.brandC }, { cfg.brandC = it })

        label(root, "— অন্যান্য —", true)
        toggle(root, "বাংলা সংখ্যা (১ ২ ৩ ...)", cfg.bn) { cfg.bn = it }
        toggle(root, "ব্র্যান্ড লেখা দেখান", cfg.showBrand) { cfg.showBrand = it }

        label(root, "ব্র্যান্ড লেখা", false)
        val brand = EditText(this)
        brand.setSingleLine()
        brand.setText(cfg.brandText)
        brand.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(e: Editable?) {
                cfg.brandText = e?.toString() ?: ""
                refresh()
            }
        })
        root.addView(brand)

        val save = Button(this)
        save.text = "সংরক্ষণ করুন ও উইজেট আপডেট করুন"
        save.setOnClickListener {
            ClockWidgetProvider.updateAll(this)
                finish()
        }
        root.addView(save)

        refresh()
    }

    override fun onPause() {
        super.onPause()
        ClockWidgetProvider.updateAll(this)
    }

    // ---------- ফাইল বাছাই ----------
    private fun pickFile(mime: String, req: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = mime
        startActivityForResult(i, req)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            REQ_PHOTO -> importPhoto(uri)
            REQ_FONT -> importFont(uri)
        }
    }

    private fun importFont(uri: Uri) {
        try {
            var name = "font.ttf"
            contentResolver.query(uri, null, null, null, null)?.use { cur ->
                val i = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && cur.moveToFirst()) name = cur.getString(i) ?: name
            }
            val lower = name.lowercase()
            if (!lower.endsWith(".ttf") && !lower.endsWith(".otf")) {
                toast("শুধু .ttf বা .otf ফন্ট ফাইল বাছুন")
                return
            }
            val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
            val dest = File(cfg.fontsDir(), safe)
            contentResolver.openInputStream(uri)?.use { ins ->
                FileOutputStream(dest).use { ins.copyTo(it) }
            }
            try {
                android.graphics.fonts.Font.Builder(dest).build() // ফন্ট বৈধ কি না যাচাই
            } catch (e: Exception) {
                dest.delete()
                toast("এই ফন্ট ফাইলটি পড়া যায়নি")
                return
            }
            fontRows.forEach { bindFontRow(it) }
            toast("ফন্ট যোগ হয়েছে: " + safe + " — এখন ফন্ট তালিকা থেকে বাছুন")
        } catch (e: Exception) {
            toast("ফন্ট যোগ করা যায়নি: " + e.message)
        }
    }

    private fun importPhoto(uri: Uri) {
        try {
            val bounds = BitmapFactory.Options()
            bounds.inJustDecodeBounds = true
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 1800 || bounds.outHeight / sample > 1800) sample *= 2
            val opts = BitmapFactory.Options()
            opts.inSampleSize = sample
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            if (bmp == null) {
                toast("ছবি পড়া যায়নি")
                return
            }
            val orient = contentResolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)
            } ?: 1
            val m = Matrix()
            when (orient) {
                3 -> m.postRotate(180f)
                6 -> m.postRotate(90f)
                8 -> m.postRotate(270f)
            }
            val side = minOf(bmp.width, bmp.height)
            val sq = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side, m, true)
            val out = Bitmap.createScaledBitmap(sq, 800, 800, true)
            FileOutputStream(cfg.photoFile).use { out.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            cfg.usePhoto = true
            photoSwitch.isChecked = true
            refresh()
        } catch (e: Exception) {
            toast("ছবি যোগ করা যায়নি: " + e.message)
        }
    }

    // ---------- UI সহায়ক ----------
    private fun runWidgetTest(status: TextView, live: FrameLayout) {
        val rv = ClockWidgetProvider.safeViews(this, 200f, 200f)
        val msg = when (cfg.widgetLevel) {
            0 -> "✅ উইজেট লেআউট ঠিক আছে (পূর্ণ মোড)"
            4 -> "❌ উইজেট লোড হচ্ছে না"
            else -> "⚠️ উইজেট সীমিত মোডে চলছে (লেভেল ${cfg.widgetLevel})"
        }
        status.text = if (cfg.widgetError.isEmpty()) msg else msg + "\n" + cfg.widgetError
        val mgr = AppWidgetManager.getInstance(this)
        val full = mgr.getAppWidgetIds(ComponentName(this, ClockWidgetProvider::class.java)).size
        status.append("\nহোমস্ক্রিনে উইজেট: " + full + " টি")
        status.append("\nসিস্টেমের আপডেট অনুরোধ: " + cfg.sysUpdates + " বার (শেষ: " + cfg.lastSys + ")")
        try {
            live.removeAllViews()
            live.addView(rv.apply(this, live))
        } catch (e: Throwable) {
            status.append("\nপ্রিভিউ এরর: " + e.toString())
        }
    }

    private fun refresh() {
        preview.setImageBitmap(ClockFace.render(cfg, 700, true))
    }

    private fun label(parent: LinearLayout, t: String, header: Boolean) {
        val tv = TextView(this)
        tv.text = t
        tv.textSize = if (header) 17f else 15f
        if (header) tv.setTypeface(null, Typeface.BOLD)
        tv.setPadding(0, dp(if (header) 22 else 12), 0, dp(4))
        parent.addView(tv)
    }

    private fun spinner(parent: LinearLayout, title: String, items: List<String>, sel: Int, onSel: (Int) -> Unit) {
        label(parent, title, false)
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        sp.setSelection(sel)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                onSel(pos)
                refresh()
            }
            override fun onNothingSelected(a: AdapterView<*>?) {}
        }
        parent.addView(sp)
    }

    // ফন্ট স্পিনার: সিস্টেম ফন্টের সাথে আপলোড করা ফন্টও দেখায়
    private fun fontSpinner(parent: LinearLayout, title: String, get: () -> String, set: (String) -> Unit) {
        label(parent, title, false)
        val sp = Spinner(this)
        val row = FontRow(sp, get, set)
        fontRows.add(row)
        bindFontRow(row)
        parent.addView(sp)
    }

    private fun bindFontRow(r: FontRow) {
        val keys = cfg.fontKeys()
        r.spinner.onItemSelectedListener = null
        r.spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, cfg.fontNames())
        val idx = keys.indexOf(r.get()).let { if (it < 0) 2 else it }
        r.spinner.setSelection(idx, false)
        r.spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                val k = keys.getOrNull(pos) ?: return
                if (k != r.get()) {
                    r.set(k)
                    refresh()
                }
            }
            override fun onNothingSelected(a: AdapterView<*>?) {}
        }
    }

    private fun slider(
        parent: LinearLayout, title: String, min: Int, max: Int, value: Int, unit: String, onChange: (Int) -> Unit
    ) {
        val tv = TextView(this)
        tv.text = "$title: $value$unit"
        tv.setPadding(0, dp(12), 0, 0)
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = value.coerceIn(min, max) - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + min
                tv.text = "$title: $v$unit"
                if (fromUser) {
                    onChange(v)
                    refresh()
                }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(tv)
        parent.addView(sb)
    }

    private fun toggle(parent: LinearLayout, title: String, value: Boolean, onChange: (Boolean) -> Unit) {
        val sw = Switch(this)
        sw.text = title
        sw.isChecked = value
        sw.setPadding(0, dp(6), 0, dp(6))
        sw.setOnCheckedChangeListener { _, checked ->
            onChange(checked)
            refresh()
        }
        parent.addView(sw)
    }

    private fun hexOf(c: Int) = String.format("#%06X", c and 0xFFFFFF)

    private fun colorRow(parent: LinearLayout, title: String, get: () -> Int, set: (Int) -> Unit) {
        label(parent, title, false)
        val hex = EditText(this)
        hex.setSingleLine()
        hex.filters = arrayOf(InputFilter.LengthFilter(7))
        hex.setText(hexOf(get()))

        val row = LinearLayout(this)
        for (col in palette) {
            val v = View(this)
            val bgd = GradientDrawable()
            bgd.shape = GradientDrawable.OVAL
            bgd.setColor(col)
            bgd.setStroke(dp(2), 0xFF888888.toInt())
            v.background = bgd
            val lp = LinearLayout.LayoutParams(dp(36), dp(36))
            lp.setMargins(dp(4), 0, dp(4), 0)
            row.addView(v, lp)
            v.setOnClickListener {
                set(col)
                hex.setText(hexOf(col))
                refresh()
            }
        }
        val hs = HorizontalScrollView(this)
        hs.addView(row)
        parent.addView(hs)

        hex.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(e: Editable?) {
                val t = e?.toString() ?: return
                if (t.length == 7 && t[0] == '#') {
                    try {
                        set(Color.parseColor(t))
                        refresh()
                    } catch (_: IllegalArgumentException) {
                    }
                }
            }
        })
        parent.addView(hex, LinearLayout.LayoutParams(dp(140), ViewGroup.LayoutParams.WRAP_CONTENT))
    }
}
